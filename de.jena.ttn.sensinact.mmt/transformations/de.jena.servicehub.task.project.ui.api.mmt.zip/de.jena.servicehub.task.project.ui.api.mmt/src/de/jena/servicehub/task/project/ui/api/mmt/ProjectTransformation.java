/**
 * Copyright (c) 2012 - 2018 Data In Motion and others.
 * All rights reserved. 
 * 
 * This program and the accompanying materials are made available under the terms of the 
 * Eclipse Public License v1.0 which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Data In Motion - initial API and implementation
 */
package de.jena.servicehub.task.project.ui.api.mmt;

import java.util.List;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import de.jena.servicehub.task.project.ui.api.mmt.exception.UnknownTransformationException;

/**
 * @author jalbert
 *
 */
public interface ProjectTransformation {

	/**
	 * Transforms any given Object
	 * @param source the source Object to transform
	 * @param to the EClass to transform into
	 * @return the transformed Object
	 * @throws UnknownTransformationException
	 */
	public <T extends EObject> T transform(EObject source, EClass to) throws UnknownTransformationException;

	/**
	 * Transforms any given Object
	 * @param source the source Object to transform
	 * @param to the EClass to transform into
	 * @param sourceEClass the sourceEClass to transform
	 * @return the transformed Object
	 * @throws UnknownTransformationException
	 */
	public <T extends EObject> T transform(EObject source, EClass sourceEClass, EClass to) throws UnknownTransformationException;

	/**
	 * Transforms any given Object
	 * @param source
	 * @param to
	 * @return
	 * @throws UnknownTransformationException
	 */
	public <T extends EObject> List<T> transform(List<? extends EObject> source, EClass to) throws UnknownTransformationException;
	
}
