/**
 * Copyright (c) 2012 - 2018 Data In Motion and others.
 * All rights reserved. 
 * 
 * This program and the accompanying materials are made available under the terms of the 
 * Eclipse Public License v1.0 which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Data In Motion - initial API and implementation
 */
package de.jena.servicehub.task.project.ui.api.mmt.impl;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.gecko.core.pool.Pool;
import org.gecko.qvt.osgi.api.ConfigurableModelTransformatorPool;
import org.gecko.qvt.osgi.api.ModelTransformator;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.log.Logger;
import org.osgi.service.log.LoggerFactory;

import de.jena.servicehub.task.project.ui.api.mmt.ProjectTransformation;
import de.jena.servicehub.task.project.ui.api.mmt.exception.UnknownTransformationException;


/**
 * @author ilenia
 *
 */
//@Component
@Component(name = "apiModelTransformator")
public class ProjectTransformationImpl implements ProjectTransformation {

	@Reference(service = LoggerFactory.class)
	private Logger logger;
	
//	@Reference
	@Reference(target = ("(pool.componentName=modelTransformatorService)"))
	private ConfigurableModelTransformatorPool poolComponent;

	@Activate
	public void activate() {
		logger.debug("Project Tranformation Impl is active!");
	}
	
	@Override
	public <T extends EObject> T transform(EObject source, EClass to) throws UnknownTransformationException {
		return transform(source, source.eClass(), to);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends EObject> T transform(EObject source, EClass sourceEClass, EClass to)
			throws UnknownTransformationException {
		String trafo = buildTemplatename(sourceEClass, to);
		logger.debug("searching for Trafo " + trafo);
//		long start = System.currentTimeMillis();
		Pool<ModelTransformator> pool = poolComponent.getPoolMap().get(trafo);
//		System.err.println("get pool " + (System.currentTimeMillis() - start) + " ms");
		if(pool == null) {
			logger.warn("No Trafo found for " + trafo);
			throw new UnknownTransformationException("Could not find " + trafo);
		}
//		start = System.currentTimeMillis();
		ModelTransformator modelTransformator = pool.poll();
//		start = System.currentTimeMillis();
		try {
			return (T) modelTransformator.startTransformation(source);
		} finally {
//			System.err.println(sourceEClass.getName() + " transform " + (System.currentTimeMillis() - start) + " ms with " + modelTransformator.toString());
//			start = System.currentTimeMillis();
			pool.release(modelTransformator);
//			System.err.println("release " + (System.currentTimeMillis() - start) + " ms");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends EObject> List<T> transform(List<? extends EObject> sourceList, EClass to)
			throws UnknownTransformationException {
		if(sourceList.isEmpty()) {
			return Collections.emptyList();
		}
		EClass sourceEClass = getSourceEClass(sourceList);
		String trafo = buildTemplatename(sourceEClass, to);
		logger.debug("searching for Trafo " + trafo);
		Pool<ModelTransformator> pool = poolComponent.getPoolMap().get(trafo);
		
		if(pool == null) {
			logger.warn("No Trafo found for " + trafo);
			throw new UnknownTransformationException("Could not find " + trafo);
		}
		ModelTransformator modelTransformator = pool.poll();
		try {
			List<? extends EObject> result = modelTransformator.startTransformations(sourceList);
			result = result.stream().filter(eo -> eo.eClass().isSuperTypeOf(to)).collect(Collectors.toList());
			return (List<T>) result;
		} finally {
			pool.release(modelTransformator);
		}
	}
	
	private String buildTemplatename(EClass source, EClass to) {
		String poolComponentName = "modelTransformatorService";
		String trafo = source.getEPackage().getNsPrefix() + "2" + to.getEPackage().getNsPrefix();
		String combinedId = poolComponentName+"-"+trafo;
		return combinedId;
	}
	
	private EClass getSourceEClass(List<? extends EObject> sourceList) {
		EClass sourceEClass = sourceList.get(0).eClass();
		for(int i = 0; i < sourceList.size(); i++) {
			EObject eo = sourceList.get(i);
			if(eo.eClass() != sourceEClass) {
				throw new IllegalArgumentException("All EObjects in the list must be of the same type found first Object was of type " + sourceEClass.getName() + " but EClass at index " + i + " was " + eo.eClass());
			}
		}
		return sourceEClass;
	}
}
